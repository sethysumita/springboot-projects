package com.example.demo.model;

public class Chat {
 private int ChatId;
 private String content;

public int getChatId() {
	return ChatId;
}

public void setChatId(int chatId) {
	ChatId = chatId;
}

public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}
public Chat() {
	super();
	
}

}
