package com.example.demo.model;

import lombok.Data;

@Data
public class Employee {
	private String senderId;
	private String receiverId;
	private String content;
	

}
